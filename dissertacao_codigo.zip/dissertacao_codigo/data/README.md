# Dados de entrada

Esta pasta tem de conter os dois ficheiros do BDG2 usados pelo pipeline:

* `electricity_cleaned.csv`
* `weather.csv`

Os ficheiros não são distribuídos neste repositório. O `electricity_cleaned.csv`
tem 166,9 MiB e excede o limite de 100 MiB por ficheiro imposto pelo GitHub.

O BDG2 é público e está disponível em
https://github.com/buds-lab/building-data-genome-project-2

Descarregar os dois ficheiros dessa fonte e colocá-los nesta pasta antes de
executar o pipeline. Os identificadores dos edifícios têm de manter o formato
`site_tipologia_nome` usado no BDG2, porque o código extrai deles o *site* e a
tipologia do edifício.
